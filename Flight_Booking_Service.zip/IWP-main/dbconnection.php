<?php 
$con=mysqli_connect('localhost','root','','fairlines');
if(mysqli_connect_errno($con))
{
	die("Connection error");
 }
 ?>
